﻿#develop own tool

function add{

   [int]$a = Read-Host "enter data"
   [int]$b = Read-Host "enter data"

   [int]$c = $a+$b 
   Write-Host "sum of two numbers $c"

}
function sub{

    [int]$a = Read-Host "enter data"
   [int]$b = Read-Host "enter data"

   [int]$c = $a-$b 
   Write-Host "sub of two numbers $c"
}
function process-list{

    $out = Get-Process

    $out | Add-Content "C:\Users\vkumar15\Desktop\out.txt"
}


#iterate 
while($true){

    [int]$ch = Read-Host "press 1 for add 2 for sub 3 for process 0 for exit "
    $ch 
    if($ch -eq 1){
                add 
    }

    elseif($ch -eq 2){
                sub 
    }
    elseif($ch -eq 3){
                process-list
    }
    elseif($ch -eq 0){
                break
    }
    else{

            Write-Host "Invalid choice , plz try again"
    }



}

