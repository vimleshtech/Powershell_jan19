﻿
$pwd = "testpwd"

$password = Get-Content "C:\Passwords\password.txt" | ConvertTo-SecureString 
$credential = New-Object System.Management.Automation.PsCredential("Luke",$password)


##typecst pwd
$pwd = Get-Content "" ConvertFrom-SecureString
