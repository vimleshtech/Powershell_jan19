﻿
function Add-Numbers($a,$b){
    $c = $a+$b 
    Write-Host  "add of two numbers $c "
}



function Sub-Numbers($a,$b){
    $c = $a-$b 
    Write-Host  "sub of two numbers $c "
}